# Yandere Simulator: Decadência Após 10 Anos

Este vídeo, em um tom informal e sem palavrões, reage ao vídeo "A Decadência de Yandere Simulator" do canal Malusquet, analisando o desenvolvimento problemático do jogo ao longo de 10 anos.

**Principais Pontos:**

*   **Hype Inicial:** Yandere Simulator atraiu muita atenção em 2015/2016 por sua premissa única: um jogo de anime com elementos de Bully e Hitman, onde uma colegial psicopata elimina rivais amorosas.
*   **Falta de Foco:** O jogo sofre de falta de foco, com muitas adições e mudanças que impedem o desenvolvimento do núcleo principal.
*   **Apoio Rejeitado:** Várias empresas e indivíduos se ofereceram para ajudar no desenvolvimento, mas o desenvolvedor principal (YandereDev) recusou ou não conseguiu coordenar essa ajuda efetivamente.
*   **Modo 1980:** Um modo de jogo completo dentro de Yandere Simulator, com 10 rivais e uma história completa, foi lançado antes do jogo principal estar terminado. Isso gerou revolta na comunidade, já que provou que o desenvolvedor era capaz de criar conteúdo completo, mas não o fazia com o jogo principal.
*   **Atualizações Supérfluas:** O desenvolvimento se concentra em detalhes pequenos e refinamentos, enquanto o jogo principal permanece incompleto.
*   **Financiamento Contínuo:** O jogo continua a receber financiamento através do Patreon, mesmo com o desenvolvimento lento e problemático, o que sugere que o desenvolvedor não tem incentivo para terminar o jogo.
*   **Teoria do Dinheiro:** O apresentador levanta a hipótese de que o desenvolvedor está propositalmente atrasando o desenvolvimento para continuar recebendo financiamento mensalmente.
*   **Burrice Estratégica:** O apresentador chega à conclusão que o desenvolvedor é burro em não lançar o jogo, mesmo com bugs, e aproveitar a notoriedade para criar sequências ou remakes.

**Conclusão:**

*   O principal ponto de discussão é a falta de progresso no desenvolvimento de Yandere Simulator após 10 anos.
*   A existência do Modo 1980, que é um jogo completo dentro do jogo inacabado, agrava a frustração da comunidade.
*   O financiamento contínuo do jogo, mesmo com o desenvolvimento lento e problemático, é visto como um fator que impede o progresso.
*   A mensagem central é que o desenvolvedor está intencionalmente atrasando o desenvolvimento para manter o fluxo de financiamento, e que a comunidade que o financia é, em última análise, responsável por perpetuar esse ciclo vicioso.
*   O vídeo conclui que é hora de o jogo afundar na merda para que o desenvolvedor se sinta forçado a terminá-lo.
