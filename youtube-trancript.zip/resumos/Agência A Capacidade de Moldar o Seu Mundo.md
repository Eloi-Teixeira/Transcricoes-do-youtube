# Agência: A Capacidade de Moldar o Seu Mundo

Este vídeo, com um tom informal e sem palavrões, explora o conceito de agência, que é a capacidade de moldar o próprio ambiente em vez de ser moldado por ele.

## O que é Agência?

*   Agência está ligada à vontade, que é a capacidade de decidir e agir de acordo com essa decisão ao longo do tempo.
*   É uma habilidade essencial, especialmente no mundo atual, repleto de opções.
*   Pessoas com alta agência "fazem acontecer" e parecem ter uma energia e vontade acima da média.

## Traços de Pessoas com Alta Agência

*   **Hobbies Estranhos:** Vão contra o senso comum e demonstram capacidade de decisão e persistência, mesmo diante de críticas.
*   **Energizam:** Estar perto delas te motiva e te incentiva a agir.
*   **Imprevisibilidade:** Não se encaixam em estereótipos e suas opiniões são surpreendentes.
*   **Mentalidade Imigrante:** Não têm medo de mudar e sair da zona de conforto.
*   **Compartilham Conteúdo de Nicho:** Reconhecem o valor de criadores e tendências antes da popularização.
*   **Sinceridade:** São honestas, mesmo que a verdade seja desconfortável.
*   **Largaram Algo Prestigiado:** Tiveram a capacidade de decisão de deixar um lugar "seguro" para buscar algo novo.
*   **Confiam, mas Verificam:** Buscam se aprofundar em informações, em vez de aceitar tudo passivamente.
*   **Aprendizes Autodidatas:** Buscam autonomia no aprendizado e não esperam permissão para avançar.
*   **Questionam a Pergunta:** Sabem que uma resposta perfeita para uma pergunta errada é inútil.

## A Ciência por Trás da Agência

*   Agência é um "rebranding" de conceitos como *locus* de controle e autoeficácia.
*   Uma pessoa com alta agência se vê como uma "torneira", capaz de gerar mais recursos.
*   Elas fabricam o futuro, em vez de apenas reagir ao presente.

## Três Características que Unem Pessoas com Alta Agência

*   **Pensamento Claro:** Capacidade de analisar situações sem se deixar levar pelo senso comum.
*   **Tendência à Ação:** Preferem dar o primeiro passo a ficar planejando indefinidamente.
*   **Capacidade de Discordar:** Não se dobram automaticamente à autoridade ou à opinião da maioria.

## Como Desenvolver Agência?

*   **Não Existem Problemas Insolúveis:** Acredite que sempre há uma solução e se concentre em encontrar a pergunta certa.
*   **Não Existe um Único Caminho:** Reconheça que há diferentes formas de alcançar o sucesso.
*   **Não Existem Adultos:** Ninguém tem todas as respostas, todos estão improvisando.
*   **Não Existe o Normal:** Excentricidade é um ativo de longo prazo.

## Armadilhas a Evitar

*   **Meio-Termo (Midwit):** Complicar as coisas desnecessariamente.
*   **Apego:** Ficar preso a métodos e conselhos do passado.
*   **Ruminação:** Perder tempo pensando "e se der errado?".
*   **Sobreposição:** Tentar planejar todos os passos com antecedência.

## Conclusão

*   **Mensagens:**
    *   A agência é crucial para ter controle sobre a própria vida.
    *   É possível desenvolver essa habilidade.
    *   Evitar armadilhas mentais é essencial.

*   **Mensagem Principal:** Você tem agência sobre a sua agência.

*   **Conclusão do Vídeo:** Ao escolher entre duas opções possíveis, opte por aquela que conta a melhor história, que te entusiasma e te ajuda a se tornar a pessoa que você deseja ser.
