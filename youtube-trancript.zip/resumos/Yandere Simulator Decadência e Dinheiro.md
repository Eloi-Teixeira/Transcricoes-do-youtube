# Yandere Simulator: Decadência e Dinheiro

Este resumo aborda um vídeo informal, sem palavrões, sobre a análise da decadência de Yandere Simulator, um jogo que está em desenvolvimento há 10 anos. O vídeo original, do canal "Malusquet", é assistido e comentado pelo criador de conteúdo "Core".

*   **Introdução:** O vídeo aborda a decadência de Yandere Simulator após 10 anos de desenvolvimento, utilizando como base um vídeo de análise feito pelo criador de conteúdo "Malusquet". O jogo, que prometia ser uma mistura de Bully, Hitman e anime, com uma trama de romance psicopata, nunca foi finalizado, gerando frustração na comunidade.

*   **Conceito do Jogo:** Yandere Simulator coloca o jogador no papel de uma colegial psicopata obcecada por um "Senpai". O objetivo é eliminar dez rivais amorosas ao longo de dez semanas para conquistar o amado.

*   **Problemas no Desenvolvimento:**
    *   **Falta de Foco:** O jogo parece não ter um foco claro, com muitos elementos e funcionalidades que não contribuem para o progresso geral.
    *   **Oportunidades Perdidas:** Várias empresas e desenvolvedores se ofereceram para ajudar no desenvolvimento, mas o criador principal parece resistir a colaboração.

*   **Hype e Declínio:** O jogo teve um período de grande popularidade em 2016, mas perdeu força devido à falta de progresso e polêmicas envolvendo o desenvolvedor.

*   **Modo 1980:**
    *   Um modo de jogo completo com 10 rivais, ambientado nos anos 80, foi lançado dentro do jogo incompleto.
    *   Isso gerou questionamentos sobre por que o jogo principal não é finalizado, enquanto um modo secundário está completo.
    *   "Core" expressa surpresa com a existência desse modo completo dentro de um jogo inacabado.

*   **Atualizações Supérfluas:** O jogo recebe atualizações constantes com polimentos de pixel e minigames que não contribuem para a finalização do jogo principal.

*   **Teoria Sobre o Atraso:**
    *   O vídeo levanta a suspeita de que o atraso no desenvolvimento é motivado por dinheiro, já que o desenvolvedor recebe financiamento através do Patreon.
    *   "Core" concorda com essa teoria e sugere que o jogo só será finalizado quando o financiamento parar.

*   **Críticas:** O vídeo critica quem financia o jogo, perpetuando um ciclo vicioso de desenvolvimento lento e polêmicas.

*   **Considerações Finais de "Core":** Ele expressa satisfação em se distanciar da imagem do jogo, apesar de gostar da história. Ele considera o projeto fadado ao fracasso e lamenta o potencial desperdiçado.

**Conclusão:**

*   O vídeo transmite a mensagem de que Yandere Simulator é um projeto com potencial, mas que está sendo desperdiçado devido à falta de foco, oportunidades perdidas e polêmicas envolvendo o desenvolvedor.
*   A mensagem principal é que o atraso no desenvolvimento pode ser motivado por interesses financeiros, já que o desenvolvedor recebe financiamento contínuo sem entregar o produto final.
*   O vídeo conclui que o modo 1980 prova que o desenvolvedor é capaz de criar um jogo completo, mas opta por não finalizar o projeto principal, possivelmente para manter o fluxo de dinheiro. "Core" conclui que o desenvolvedor é burro por não lançar logo o jogo e lucrar com as vendas.
