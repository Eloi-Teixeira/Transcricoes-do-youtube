Liberdade de Expressão em O Incrível Mundo de Gumball

O vídeo analisa um episódio de "O Incrível Mundo de Gumball" sobre liberdade de expressão, explorando como expressar sentimentos e opiniões de forma eficaz, mas também com responsabilidade.

### Introdução

*   O episódio não aborda a liberdade de expressão no sentido político, mas sim a capacidade de expressar ou reprimir sentimentos pessoais.
*   Darwin é o foco inicial, sofrendo em silêncio com o comportamento irritante de Suzi no ônibus.

### O Problema da Repressão

*   Darwin prefere a dor física (pedindo para Gumball bater em sua cabeça) do que confrontar Suzi.
*   Muitas vezes, as pessoas se sufocam por falta de coragem para evitar conflitos ou por vergonha.

### A Solução Inicial de Gumball

*   Gumball demonstra como pedir algo de forma educada e assertiva, sem grosseria.
*   A chave está em pensar antes de falar, embora Gumball pareça agir por instinto, ele entende o que ele quer antes de pensar sobre como expressá-lo
*   As pessoas se preocupam demais com o que os outros pensarão ou com sua própria imagem.

### A Lição de Ser Direto (e suas Consequências)

*   Gumball decide "ensinar" Darwin a ser direto, o que resulta em humilhação (fazer Darwin se esfregar no chão).
*   A cena é comparada à história do filósofo Zenão, que foi exposto à humilhação pública para superar a timidez e a preocupação com a opinião alheia.

### Honestidade e Sinceridade vs. Achismo e Grosseria

*   Darwin começa a ser "honesto" com todos, mas muitas vezes acaba sendo grosseiro e criticando coisas que as pessoas não podem mudar.
*   Ser honesto não garante que você esteja certo; pode ser apenas sua opinião ou achismo.
*   É importante saber quando falar e quando se calar, pois a liberdade de expressão não significa que você deve expressar tudo que pensa.

### O Musical da Verdade Cruel

*   Darwin canta uma música revelando seus pensamentos negativos sobre os outros.
*   Isso leva ao isolamento, mostrando que nem tudo que sentimos ou pensamos deve ser expresso.

### A Importância da Sensibilidade e Empatia

*   O vídeo enfatiza a necessidade de sensibilidade e empatia ao expressar opiniões.
*   Criticar coisas que as pessoas não podem mudar ou que não afetam diretamente você é desnecessário e cruel.
*   Darwin é retratado como alguém que quer que o mundo se adapte a ele, agindo como um "bebê chorão".

### A Verdade Dolorosa e a Lição Final

*   Gumball, para parar Darwin, revela que Darwin é apenas seu animal de estimação.
*   Isso magoa profundamente Darwin, mas o faz entender o impacto de suas palavras.
*   Gumball maquia a verdade para confortar Darwin, mostrando que, às vezes, a compaixão é mais importante do que a honestidade brutal.
*   A conclusão é que a liberdade de expressão é importante, mas a sabedoria para saber quando e como usá-la é essencial.
