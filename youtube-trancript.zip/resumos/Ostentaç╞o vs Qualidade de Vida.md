# Ostentação vs. Qualidade de Vida

Este vídeo apresenta uma reflexão informal, sem palavrões, sobre a cultura da ostentação e como ela afeta as prioridades financeiras das pessoas, especialmente em um contexto onde muitos se endividam para manter uma imagem de riqueza que não condiz com a realidade.

## Pontos-Chave

*   **Crítica à Cultura da Grife:**
    *   O autor critica a ideia de se endividar para comprar roupas de grife apenas para aparentar ser mais rico.
    *   Ele menciona conhecer blogueiros de moda que se endividam para manter essa imagem.
*   **Ostentação vs. Necessidade:**
    *   Diferencia ostentação de gostar de marcas como Nike, ressaltando que existem itens muito mais caros.
    *   Compartilha que muitos de seus tênis foram ganhos ou comprados para criar conteúdo e gerar renda.
*   **Preços Abusivos e Qualidade:**
    *   Critica os preços da Nike no Brasil, considerando-os um abuso.
    *   Desaconselha a compra de tênis como o Dunk devido à sua baixa qualidade e durabilidade.
*   **Armadilhas da Moda:**
    *   Alerta sobre a busca por itens da moda, como cintos de marcas de luxo, que perdem valor rapidamente.
    *   Critica a cultura do "quanto custa o outfit", associando-a a um estilo de vida de playboy.
*   **Valorização da Qualidade:**
    *   Defende a compra de produtos de qualidade, mesmo que sejam mais caros, como calças da Levis (sem incentivar o endividamento).
*   **Inversão de Prioridades:**
    *   Critica a influência de letras de funk, influenciadores e redes sociais que promovem a ostentação.
    *   Ressalta a importância de rever prioridades, mencionando experiências pessoais que o fizeram repensar sua relação com o dinheiro.
*   **Saúde e Qualidade de Vida:**
    *   Prioriza investimentos em saúde, como treinar jiu-jitsu e ter acompanhamento de um personal trainer.
    *   Valoriza momentos de qualidade com a família e viagens.
*   **Consumo Consciente:**
    *   Enfatiza a importância de se vestir bem para se sentir bem, mas sem se endividar.
    *   Incentiva a compra de produtos que se encaixam no orçamento pessoal, como tênis de marcas mais acessíveis.
*   **Prosperidade:**
    *   Distingue prosperidade de comprar coisas, afirmando que prosperar é ter paz e dinheiro suficiente para viver bem com a família.

## Conclusão

*   **Mensagens:**
    *   A importância de repensar o conceito de ostentação e priorizar a qualidade de vida, a saúde e o bem-estar familiar.
    *   A crítica à cultura do consumo exagerado e da busca por status através de bens materiais.
*   **Mensagem Principal:**
    *   Prosperidade não é sinônimo de comprar coisas, mas sim de ter paz e condições para viver bem.
*   **Conclusão do Vídeo:**
    *   É fundamental ter consciência financeira e evitar o endividamento para manter uma imagem de riqueza que não condiz com a realidade.
