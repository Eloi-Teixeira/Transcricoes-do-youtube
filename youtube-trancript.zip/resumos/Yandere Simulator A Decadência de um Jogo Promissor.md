# Yandere Simulator: A Decadência de um Jogo Promissor

Este resumo aborda o vídeo em que o criador de conteúdo, com uma linguagem informal e sem palavrões, reage a um vídeo do canal Malusquet sobre a situação atual de Yandere Simulator após 10 anos de desenvolvimento.

## Análise e Opiniões Sobre o Desenvolvimento

*   O jogo prometia ser uma mistura única de Bully, Hitman e anime com uma temática de romance psicopata, gerando grande expectativa.
*   Um dos principais problemas apontados é a falta de foco do desenvolvedor, que adiciona muitos elementos e skins sem priorizar o desenvolvimento do núcleo do jogo.
*   Várias empresas e desenvolvedores se ofereceram para ajudar, inclusive com propostas de compra, mas o projeto não avançou significativamente.
*   O jogo, apesar de ter evoluído em comparação com o início do projeto, ainda possui apenas duas rivais (personagens a serem eliminadas) prontas, de um total de dez, após 10 anos.
*   O criador de conteúdo confessa que, assim como Malusquet, também se sentiu "preso" a um jogo (Five Nights at Freddy's) por conta do engajamento e receita que ele proporcionava, mesmo desejando produzir outros tipos de conteúdo.

## O Modo 1980 e a Decadência Exposta

*   O lançamento do "Modo 1980", que apresenta a história da mãe da protagonista com as 10 rivais completas, causou grande surpresa e revolta na comunidade.
*   O modo completo dentro de um jogo incompleto levanta questões sobre a prioridade do desenvolvedor e sua capacidade de finalizar o projeto principal.
*   O criador do vídeo original (Malusquet) critica as atualizações de "polimento de pixel", que focam em detalhes mínimos em vez de completar o jogo base.

## A Teoria do Financiamento e a Indignação

*   O criador do vídeo original (Malusquet) levanta a hipótese de que o desenvolvimento lento é intencional, pois o desenvolvedor recebe apoio financeiro através do Patreon.
*   A falta de incentivo para finalizar o jogo, combinada com a receita contínua, cria um ciclo vicioso que prejudica o projeto.
*   O criador de conteúdo expressa frustração com aqueles que financiam o projeto, permitindo que o desenvolvedor continue a entregar migalhas em vez de um jogo completo.

## Conclusões

*   O vídeo busca trazer à tona a problemática do desenvolvimento de Yandere Simulator, que se arrasta por 10 anos sem conclusão.
*   A mensagem principal é que a falta de foco, as polêmicas do desenvolvedor e, principalmente, o financiamento contínuo do projeto contribuem para a sua decadência.
*   O criador de conteúdo conclui que o desenvolvedor é capaz de completar o jogo, como demonstrado pelo "Modo 1980", mas opta por não fazê-lo devido à comodidade financeira.
*   O criador de conteúdo, no final do vídeo, expressa sua felicidade em estar se distanciando da imagem atrelada ao jogo.
