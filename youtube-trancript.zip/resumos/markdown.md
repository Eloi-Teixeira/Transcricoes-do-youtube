```markdown
# Resumo do Vídeo: Sumiço do Canal, 100k e Desafios Pessoais

## Introdução

O vídeo explica o sumiço do criador de conteúdo do canal por mais de um mês, abordando a conquista de 100 mil inscritos, a trajetória do canal e a vida pessoal do criador, incluindo os desafios que o afastaram da programação.

## Celebrando os 100k Inscritos

*   O criador compartilha sua alegria por alcançar a marca de 100.000 inscritos.
*   Menciona ter outros canais no YouTube, incluindo um canal de música com 45.000 inscritos, um de criptomoedas, um de anime e um sobre sua vida em Portugal.
*   Ressalta que este é o maior canal que já teve, sendo que os anteriores sempre foram menores (20-60 mil inscritos).
*   Agradece aos inscritos e menciona que a placa de 100k representa uma superação e trajetória de vida.

## Origem e Motivação para a Programação

*   Na pandemia, buscou uma profissão que oferecesse mais estabilidade do que a internet.
*   Relata suas dificuldades financeiras e familiares desde a infância:
    *   Família desestruturada.
    *   Expulso de casa aos 12 ou 13 anos.
    *   Morou em casas precárias e passou fome.
    *   Vida conturbada desde os 13 anos.
*   Cansado de subempregos e da instabilidade financeira, decidiu estudar programação.
*   Criou o canal para documentar sua trajetória nos estudos.

## A Trajetória na Programação

*   Começou a estudar programação na pandemia.
*   Achou o início difícil e duvidou da sua capacidade de aprender.
*   Conseguiu um estágio com a ajuda de um amigo (João).
*   Evoluiu e construiu uma plataforma sozinho (Futuro Dev Academy).
*   Agradece o apoio da comunidade, que o ajudou a chegar aos 100 mil inscritos.

## O Sumiço Recente e os Desafios Atuais

*   Nos últimos dois meses, tem enfrentado problemas de saúde mental (depressão, ansiedade, crise de pânico).
*   Esses problemas o impediram de gravar vídeos e se dedicar à programação.
*   Teve que adiar projetos importantes, como a Futuro Dev Academy e uma oportunidade de trabalho como programador em Portugal.
*   A plataforma Futuro Dev Academy continua no ar.
*   Está tentando voltar à rotina e fazer *freelances* com um amigo (Wellington).
*   Busca uma vaga de emprego 100% remota devido aos seus problemas de saúde.

## Futuro do Canal e da Programação

*   Não pode prometer uma volta 100% imediata ao canal, mas espera voltar a postar vídeos regularmente (quinzenalmente ou semanalmente).
*   Não pretende abandonar a programação, mas precisa lidar com seus problemas de saúde.
*   Agradece novamente o apoio de todos e afirma que não estaria onde está hoje sem a ajuda dos seus seguidores.
*   Rebate comentários de que seria "filhinho de papai" por morar na Europa, afirmando que sua vida não foi fácil.
```