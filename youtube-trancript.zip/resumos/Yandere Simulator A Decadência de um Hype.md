# Yandere Simulator: A Decadência de um Hype

Este resumo aborda a análise do vídeo de Malusquet sobre a decadência do jogo Yandere Simulator, com tom informal sem palavrões. O vídeo explora os 10 anos de desenvolvimento do jogo, as polêmicas envolvidas e o impacto disso na comunidade.

## Pontos Chave

*   **O Conceito Inicial:** Yandere Simulator prometia ser um jogo inovador, combinando elementos de Bully, Hitman e anime, com uma temática de romance psicopata.
*   **Falta de Foco:** O jogo sofre de uma falta de foco, com constantes adições de conteúdo que não contribuem para o progresso do desenvolvimento principal.
*   **Oportunidades Perdidas:** Várias empresas e desenvolvedores se ofereceram para ajudar no desenvolvimento, mas a ajuda foi constantemente rejeitada.
*   **Hype e Visibilidade:** O jogo gerou grande hype em 2016, impulsionando canais no YouTube, mas essa fama trouxe uma dependência do jogo para muitos criadores de conteúdo, inclusive o próprio Core.
*   **Modo 1980:** O lançamento do modo 1980, um modo completo dentro de um jogo incompleto, com todas as 10 rivais prontas, escancarou a decadência do projeto, levantando questionamentos sobre o porquê do jogo principal não estar completo.
*   **Atualizações Superficiais:** O jogo recebe constantemente atualizações cosméticas, minigames e adições que não contribuem para a finalização do jogo.
*   **Financiamento Contínuo:** Apesar dos anos de desenvolvimento e da falta de progresso, o desenvolvedor continua recebendo financiamento através do Patreon.
*   **Polêmicas:** O vídeo evita aprofundar nas polêmicas do desenvolvedor, mas reconhece que elas contribuíram para a perda de hype do jogo.

## Conclusão

O vídeo de Malusquet e as reações do Core apontam para:

*   **Mensagens:**
    *   Yandere Simulator é um projeto com potencial desperdiçado.
    *   O desenvolvimento lento e as polêmicas contribuíram para a decadência do jogo.
    *   O financiamento contínuo pode estar perpetuando a falta de progresso.
*   **Mensagem Principal:** O vídeo critica a forma como o projeto Yandere Simulator está sendo conduzido e o ciclo vicioso de financiamento que impede o seu término.
*   **Conclusão Apresentada:** O Core acredita que o desenvolvedor está intencionalmente atrasando o lançamento do jogo para continuar recebendo apoio financeiro, e que o lançamento do modo 1980 provou que ele é capaz de entregar um jogo completo.
