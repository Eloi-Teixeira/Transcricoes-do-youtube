# Medo da CLT pelos Jovens

Vídeo informal, com algumas expressões informais.

*   **Introdução**
    *   O vídeo aborda o medo que jovens têm da CLT (Consolidação das Leis do Trabalho), influenciado por ideias online e coachs.
    *   A apresentadora, Fabi, relata ter percebido esse medo em conversas com adolescentes, que associam a CLT a pobreza e condições de trabalho desfavoráveis.

*   **Desmistificando a CLT**
    *   A CLT garante direitos trabalhistas, como férias, 13º salário e FGTS.
    *   Existem CLTs que ganham salários altos, desfazendo a ideia de que ser CLT é sinônimo de pobreza.
    *   A CLT é um caminho tradicional para iniciar no mercado de trabalho e adquirir segurança antes de pensar em empreender.

*   **PJotização e a Realidade do Empreendedorismo**
    *   O vídeo critica a pejotização, prática em que empresas substituem contratos CLT por contratos PJ (Pessoa Jurídica), muitas vezes sem oferecer os mesmos benefícios e direitos.
    *   O empreendedorismo é romantizado online por coachs que vendem cursos, mas a realidade é que empreender é difícil, exige muito trabalho e não é para todos.
    *   Empreender envolve correr atrás de clientes, fornecedores, lidar com impostos e planejamento financeiro.

*   **CLT Premium vs. Realidade Brasileira**
    *   Embora muitos CLTs ganhem mal, existem aqueles com salários altos e benefícios excelentes, o chamado "CLT Premium".
    *   O vídeo critica a alta carga tributária no Brasil, que dificulta tanto para empresas quanto para empreendedores.
    *   O jovem associa empreender com liberdade, mas pode encontrar menos liberdade do que ser CLT, pois terá que correr atrás de clientes e pagar contas.

*   **Caminhos de Carreira**
    *   Existem diversos caminhos de carreira, como CLT, empreendedorismo, concurso público, etc.
    *   A escolha do caminho depende da profissão, dos gostos e dos objetivos de vida.
    *   Demonizar a CLT é conveniente para chefes abusivos, pois a CLT define regras de interação, justiça e evita abusos no trabalho.

*   **Conclusão**

    *   O vídeo busca desmistificar o medo da CLT, mostrando que ela garante direitos e pode ser um bom ponto de partida.
    *   Alerta para a romantização do empreendedorismo e a realidade difícil de empreender no Brasil.
    *   A mensagem principal é que existem diversos caminhos de carreira e que a CLT é um deles, com seus prós e contras, e que deve ser valorizada como um conjunto de regras que protegem o trabalhador.
    *   O vídeo conclui incentivando os jovens a se informarem sobre seus direitos e a não se deixarem influenciar por ideias simplistas sobre o mundo do trabalho.
