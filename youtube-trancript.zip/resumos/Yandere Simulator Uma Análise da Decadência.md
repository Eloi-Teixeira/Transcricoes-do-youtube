# Yandere Simulator: Uma Análise da Decadência

Este resumo aborda um vídeo em tom informal, sem palavrões, que analisa a situação atual do jogo Yandere Simulator, dez anos após o início de seu desenvolvimento, focando nas problemáticas do projeto e nas atitudes do desenvolvedor.

## Pontos-Chave

*   **Contexto:** O vídeo reage a uma análise da decadência de Yandere Simulator feita pelo criador de conteúdo Malusquet, após 10 anos de desenvolvimento do jogo.
*   **O Jogo:** Yandere Simulator é descrito como uma mistura de Bully (Rockstar), estética anime, mecânicas de Hitman e uma trama de romance psicopata. A premissa envolve uma protagonista com psicopatia Yandere que precisa eliminar 10 rivais em 10 semanas para ficar com seu "Senpai".
*   **Problemas de Foco:** O jogo é criticado por ter "muita coisa" e falta de foco. Empresas tentaram ajudar, até comprar os direitos, mas sem sucesso.
*   **Hype e Queda:** O jogo gerou grande hype em 2016, impulsionando canais no YouTube. No entanto, o desenvolvimento lento e as polêmicas do desenvolvedor contribuíram para a perda de interesse.
*   **Modo 1980:** Um modo de jogo completo com 10 rivais jogável, ambientado nos anos 80, foi lançado dentro do jogo inacabado. Isso gerou questionamentos sobre por que o modo principal não é finalizado.
*   **Atualizações Supérfluas:** O vídeo critica o excesso de atualizações cosméticas e minigames que não contribuem para a finalização do jogo principal.
*   **Financiamento e Patreon:** O desenvolvedor recebe cerca de U$ 8.000 por mês no Patreon, o que é apontado como um possível motivo para a lentidão no desenvolvimento.
*   **Teoria da Conspiração:** A teoria principal é que o jogo se arrasta porque é lucrativo para o desenvolvedor, criando um ciclo vicioso.
*   **Crítica aos Financiadores:** A crítica final é direcionada a quem financia o jogo, permitindo que o ciclo continue.
*	**Relevância Pessoal:** O criador do vídeo expressa felicidade em se distanciar da imagem atrelada ao jogo, mesmo reconhecendo seu potencial desperdiçado.

## Conclusão

*   **Mensagem Principal:** Yandere Simulator é um projeto com potencial, mas fadado ao fracasso devido à má gestão e ganância do desenvolvedor.
*   **Lições:** É importante apoiar projetos com progresso real e não alimentar ciclos viciosos que exploram a paciência dos fãs.
*   **Conclusão do vídeo:**
    *   O modo 1980 provou que o desenvolvedor consegue fazer o jogo completo se quiser.
    *   O jogo não é lançado porque é mais lucrativo mantê-lo em desenvolvimento contínuo, recebendo financiamento mensal.
    *   O desenvolvedor é burro por não lançar o jogo e explorar outras oportunidades, como um remake ou Yandere Simulator 2.
    *   O vídeo termina incentivando os espectadores a deixarem o "gostei", se inscreverem no canal e visitarem o canal do Malusquet.
