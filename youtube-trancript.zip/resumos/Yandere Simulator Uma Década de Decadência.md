# Yandere Simulator: Uma Década de Decadência

Este é um resumo de um vídeo que utiliza uma linguagem informal para analisar o estado atual do jogo Yandere Simulator após 10 anos de desenvolvimento. O vídeo explora as razões por trás da falta de progresso e o impacto disso na comunidade e nos criadores de conteúdo.

## Análise do Vídeo de Malusquet

*   O vídeo analisa a decadência de Yandere Simulator após 10 anos de desenvolvimento.
*   O criador de conteúdo, CorE, reage ao vídeo de Malusquet, concordando com a análise e expressando surpresa com algumas informações.
*   O jogo, inicialmente promissor, com uma mistura de elementos de Bully, Hitman e anime, enfrenta problemas de foco e desenvolvimento.

## Problemas de Desenvolvimento e Foco

*   O jogo carece de foco, com muitas adições e pouca direção clara.
*   Empresas e desenvolvedores ofereceram ajuda, mas o progresso permanece lento.
*   O jogo está preso em um ciclo de atualizações superficiais sem avançar na história principal.

## Hype e Desilusão

*   Em 2016, o jogo ganhou destaque e gerou conteúdo popular no YouTube.
*   O criador de conteúdo CorE revela que se dedicou ao jogo devido à visibilidade e ao retorno financeiro.
*   A imagem do CorE ficou atrelada ao jogo, o que, com o tempo, se tornou um fardo.

## O Modo 1980 e a Decadência Exposta

*   O lançamento do "Modo 1980", um modo completo com 10 rivais, surpreendeu a comunidade.
*   Esse modo, que antecede a história principal, expôs a incapacidade de finalizar o jogo principal.
*   A comunidade questiona por que um modo secundário está completo enquanto o jogo original permanece incompleto.

## A Teoria do Financiamento e Enrolação

*   O vídeo levanta a questão do financiamento contínuo via Patreon.
*   Sugere-se que o desenvolvedor não tem incentivo para concluir o jogo, pois recebe apoio financeiro constante.
*   CorE argumenta que o desenvolvedor é burro, pois poderia lançar o jogo, mesmo com bugs, e potencialmente lançar uma sequência.
*   O vídeo conclui que o desenvolvedor está enrolando propositalmente para continuar recebendo dinheiro.

## Conclusão

*   O vídeo transmite uma mensagem de frustração com o estado atual de Yandere Simulator.
*   A mensagem principal é que o jogo está sendo mantido incompleto por razões financeiras, explorando a comunidade.
*   O vídeo termina com a percepção de que o desenvolvedor está agindo de má fé, explorando o sistema de financiamento contínuo.
*   CorE expressa satisfação em apoiar vídeos como o de Malusquet, com teorias bem fundamentadas.

