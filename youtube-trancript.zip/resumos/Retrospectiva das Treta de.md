# Retrospectiva das Treta de 2024

O vídeo apresenta uma retrospectiva das principais polêmicas e controvérsias que marcaram o ano de 2024 no mundo da internet, com um tom informal e pitacos do autor sobre cada situação.

## Resumo das Treta

*   **Daniel Penin e a Blaze:** O influenciador foi criticado por hipocrisia ao expor influencers que promoviam a Blaze, enquanto ele próprio vendia cursos fraudulentos de como ganhar na loteria.
*   **Cancelamento de Felca:** O influenciador foi alvo de um cancelamento considerado exagerado após o vazamento de um post privado de sua ex-namorada.
*   **Cebit vs. Sassá:** O streamer processou diversas contas por difamação após anos de indiretas e acusações de sua ex-namorada.
*   **Jun Lee e o Humor:** A influenciadora foi acusada de misoginia após fazer um vídeo de humor negro criticando outras criadoras de conteúdo.
*   **Core e o Stalker:** O streamer revelou ter sofrido perseguição de um stalker, que também importunou sua esposa, resultando em medidas judiciais.
*   **Lucas Rangel e a Foto do Feto:** O influenciador foi criticado por postar uma foto de um feto, considerada desnecessária e traumatizante.
*   **Primo Rico e o Strike:** O influenciador aplicou um strike injusto no canal de Lucas Burnie após ser criticado por declarações fora da realidade.
*   **Ronaldo (Rato Borrachudo) e as Acusações:** O streamer foi acusado injustamente de nazismo e outras coisas, gerando grande polêmica e medo.
*   **Igão e Mítico (Podpah) e a Taxação de Bilionários:** Os apresentadores do podcast foram criticados por comentários sobre taxar pessoas ricas.
*   **Gabi Xavier e o Ex-Namorado:** A influenciadora teve conversas privadas vazadas pelo ex-namorado, que a acusou de traição, o que se provou falso.
*   **Luster Flix e as Acusações:** O youtuber foi acusado de diversas irregularidades, incluindo abuso de poder e conversas impróprias com menores.
*   **Toddyn e o Curso de Jogos:** O influenciador foi criticado por lançar um curso de desenvolvimento de jogos sem ter jogos lançados e com promessas irrealistas.

## Conclusão

*   O vídeo destaca como as polêmicas na internet podem ter consequências reais e impactantes na vida das pessoas envolvidas.
*   Muitas das polêmicas envolvem exageros, acusações infundadas e invasão de privacidade, mostrando a importância do bom senso e da responsabilidade nas redes sociais.
*   O vídeo expressa o desejo de que o ano de 2025 seja mais tranquilo e que as controvérsias sejam resolvidas de forma justa e pacífica.
