# Neon Genesis Evangelion: A Jornada de um Novato

O vídeo adota uma linguagem informal, sem palavrões, para compartilhar a experiência do "Carimbo" ao assistir Neon Genesis Evangelion pela primeira vez. Ele mistura impressões pessoais com informações sobre a criação e o impacto da obra.

## Origens e Contexto

*   Criado por Hideaki Anno nos anos 90, em um momento difícil de sua vida.
*   Não queria fazer apenas mais um anime de robôs gigantes.
*   Mistura ação, psicologia e referências religiosas.
*   O anime influenciou o mangá, que começou quase ao mesmo tempo, mas terminou depois.

## Enredo Inicial e Personagens

*   Shinji Ikari, um garoto de 14 anos, é chamado pelo pai para pilotar um Eva e lutar contra anjos.
*   Shinji reluta, mas decide lutar ao ver o sofrimento de Rei Ayanami.
*   Ele passa a morar com Misato, que é chefe de operações na Nerve e tem um pinguim de estimação chamado Pen Pen.
*   Shinji é forçado a lutar contra anjos cada vez mais bizarros, enquanto busca aprovação do pai.
*   Rei Ayanami é uma piloto enigmática que intriga Shinji.

## Atmosfera e Visual

*   O visual dos anos 90 é um charme, com cores vibrantes e traços detalhados à mão.
*   As cenas de Tóquio-3 e o design dos Evas são marcantes.
*   A atmosfera do anime, mesmo com o drama, é acolhedora.

## Desenvolvimento da Trama e Conflitos

*   Asuka Langley Soryu, a segunda criança, é o oposto de Shinji, mas também tem seus próprios problemas.
*   Shinji e Asuka moram juntos com Misato, gerando situações caóticas.
*   A Nerve começa a parecer menos heroica e mais como uma organização com segredos sinistros.
*   Episódios mostram o passado dos personagens, como a visita de Shinji ao túmulo da mãe e a crise de Misato.
*   Shinji age por conta própria e fica preso dentro de um anjo, refletindo sobre si mesmo.

## Reviravoltas e Mistérios

*   Toji Suzuhara, amigo de Shinji, vira a quarta criança, mas o Eva dele se transforma em um anjo.
*   Shinji é forçado a lutar contra Toji, o que o faz desistir de pilotar novamente.
*   Um anjo destrói Asuka e Rei e invade a base, ameaçando o contato com Adão.
*   Shinji volta a pilotar e o Eva entra em modo berserker.
*   Shinji se transforma em um líquido laranja e reflete sobre sua existência.

## Reta Final e Revelações

*   Asuka não consegue mais se sincronizar com o Eva.
*   O passado de Asuka é revelado, mostrando o trauma com a mãe.
*   Rei se sacrifica, mas é revelado que ela é um clone feito com o DNA da mãe de Shinji e a alma de Lilith.
*   Kaworu Nagisa, a quinta criança, desenvolve uma relação com Shinji, mas é revelado que ele é o último anjo.
*   Shinji é forçado a matar Kaworu, o que o deixa devastado.

## The End of Evangelion: O Apocalipse Psicológico

*   A Nerve é atacada pela Seele, que quer forçar o Projeto de Instrumentalidade Humana.
*   Gendo Ikari tem seus próprios planos e quer usar o Eva-01 para se reunir com Yui.
*   Asuka desperta e luta contra as forças da Seele, mas é massacrada.
*   Misato morre tentando proteger Shinji e o beija antes de morrer.
*   Rei se funde com Lilith, virando uma entidade divina gigante.
*   Shinji entra no Eva-01 e a Instrumentalidade começa, levando a uma experiência introspectiva e caótica.

## Instrumentalidade e Escolha

*   A Instrumentalidade leva a uma fusão de todas as almas, acabando com a individualidade.
*   Shinji é confrontado com perguntas sobre dor, solidão e identidade.
*   Ele é apresentado a uma realidade paralela onde tudo deu certo, mas percebe que o vazio persiste.
*   Shinji escolhe existir, mesmo com as cicatrizes, e voltar a um mundo imperfeito, mas real.

## Conclusão

*   O vídeo transmite as seguintes mensagens:
    *   Evangelion é uma obra complexa que mistura ação, psicologia e existencialismo.
    *   A série explora temas como trauma, solidão, busca por aprovação e a natureza da identidade.
    *   O visual e a atmosfera do anime são marcantes e contribuem para a experiência.
*   A mensagem principal do vídeo é que, apesar da dor e do caos, é possível escolher existir e se conectar com os outros.
*   A conclusão do vídeo, apresentada pela obra, é que:
    *   Voltar ao normal não é ser feliz o tempo todo, mas sim estar presente e se conectar com os outros.
    *   Não se trata de vencer o mundo, mas de se encontrar nele.
