# Yandere Simulator: Decadência e Exploração

Este vídeo adota uma linguagem informal e explora a fundo a situação atual do jogo Yandere Simulator, abordando seu desenvolvimento conturbado e as polêmicas envolvendo o criador.

*   **Introdução ao Yandere Simulator:**
    *   O jogo é descrito como uma mistura de Bully (Rockstar), estética de anime, mecânicas de Hitman e uma trama de romance psicopata.
    *   A premissa envolve uma protagonista com psicopatia ("Yandere") que precisa eliminar rivais amorosas para ficar com seu "Senpai".

*   **Problemas de Desenvolvimento e Foco:**
    *   O jogo sofre de falta de foco, com excesso de memes e skins que impedem o desenvolvimento principal.
    *   Empresas já se ofereceram para ajudar, inclusive comprando os direitos, mas sem sucesso.
    *   O desenvolvimento parece não sair do lugar, com atualizações constantes que não levam a um progresso real.

*   **Hype e Visibilidade:**
    *   O jogo ganhou destaque no Brasil em 2016, atraindo muitos youtubers.
    *   O criador do vídeo surfou nessa onda, ganhando visibilidade e inscritos.
    *   No entanto, a imagem do canal ficou muito atrelada ao Yandere Simulator.

*   **A Realidade por Trás dos Vídeos:**
    *   O criador confessa que continuou produzindo conteúdo sobre o jogo por necessidade financeira.
    *   Apesar de querer diversificar, os vídeos de Yandere Simulator garantiam o pagamento das contas.

*   **O Estado Atual do Jogo:**
    *   Após 10 anos de desenvolvimento, apenas duas rivais e duas semanas estão prontas (e só uma funcional).
    *   Apesar disso, o jogo teve progresso visual e de conteúdo, com novos personagens e funcionalidades.

*   **O Modo 1980:**
    *   Para reacender o hype, foi lançado o "Modo 1980", com a mãe da personagem principal e as 10 rivais completas.
    *   Este modo completo dentro de um jogo incompleto gerou indignação e comparações.
    *   Levantou a questão de por que o modo principal não avança, enquanto o secundário está finalizado.

*   **Teorias e Financiamento:**
    *   A principal teoria é que o atraso no desenvolvimento é proposital, visando manter o financiamento via Patreon.
    *   O criador do jogo recebe cerca de 8 mil dólares por mês de apoiadores.
    *   Enquanto houver financiamento, o jogo não será finalizado.

*   **Críticas ao Desenvolvedor e Apoiadores:**
    *   O vídeo critica o desenvolvedor por se aproveitar da situação e não priorizar o lançamento do jogo.
    *   Também critica quem financia o projeto, perpetuando o ciclo vicioso.

*   **Considerações Finais:**
    *   O criador está feliz em se dissociar da imagem do jogo, que considera problemático e fadado ao fracasso.
    *   Ele acredita que o jogo tem potencial, mas está sendo consumido pelo esquecimento.
    *   Expressa frustração com outros jogos inspirados em Yandere Simulator e deseja seguir em frente.

*   **Reflexão Final do Criador do Vídeo:**
    *   Afirma que o vídeo fez ele perceber que precisa voltar a fazer vídeos legais.
    *   Reitera a burrice do desenvolvedor em não lançar o jogo, já que o Modo 1980 prova que ele é capaz.
    *   Conclui que o desenvolvedor está enrolando propositalmente para manter o financiamento.

**Conclusões:**

*   O vídeo expõe a triste situação de Yandere Simulator, um jogo com potencial, mas preso em um ciclo de desenvolvimento lento e polêmicas.
*   A mensagem principal é que o financiamento contínuo do projeto permite que o desenvolvedor continue adiando o lançamento, sem incentivo para finalizar o jogo.
*   O vídeo termina com a esperança de que, ao cessar o financiamento, o desenvolvedor seja forçado a concluir o jogo, mesmo que com bugs, para sair da situação de decadência.
