# A Decadência de Yandere Simulator

Este resumo aborda um vídeo com tom informal e sem muitos palavrões, que explora a situação atual do jogo Yandere Simulator após 10 anos de desenvolvimento, utilizando o vídeo do canal "Malusquet" como base.

*   **Introdução ao Yandere Simulator:**
    *   O jogo é descrito como uma mistura de Bully (Rockstar), estética de anime, mecânicas de Hitman e trama de romance psicopata.
    *   O objetivo é eliminar 10 rivais em 10 semanas para ficar com o "Senpai".
*   **Problemas de Foco e Desenvolvimento:**
    *   O jogo tem uma falta de foco, com muitas skins e elementos diferentes que não se integram bem.
    *   Várias empresas já se ofereceram para ajudar no desenvolvimento, mas sem sucesso.
    *   O jogo é comparado a uma pizza com excesso de queijo e molho, sem nunca finalizar os ingredientes principais.
*   **O Hype e a Realidade Atual:**
    *   Em 2016, o jogo ganhou destaque no Brasil, impulsionando canais como o do criador do vídeo.
    *   Apesar do tempo de desenvolvimento, apenas duas rivais e duas semanas estão prontas.
*   **O Modo 1980 e a Decadência Escancarada:**
    *   O modo 1980, onde se joga com a mãe da personagem principal nos anos 80, possui 10 rivais completas.
    *   Isso levanta a questão de por que um modo secundário está completo enquanto o jogo principal não avança.
*   **Teorias e Financiamento:**
    *   O desenvolvimento lento pode ser intencional, pois o criador recebe financiamento via Patreon.
    *   A crítica é direcionada a quem financia o jogo, perpetuando o ciclo vicioso.
*   **Desapego e Críticas:**
    *   O criador do vídeo expressa felicidade em se dissociar da imagem do jogo.
    *   Considera triste o potencial desperdiçado e o lento esquecimento do projeto.

**Conclusão:**

*   O vídeo critica o longo e problemático desenvolvimento do Yandere Simulator.
*   Aponta para a falta de foco e a lentidão do desenvolvimento, contrastando com o modo 1980 completo.
*   A mensagem principal é que o jogo se arrasta porque é lucrativo para o desenvolvedor, que não tem incentivo para finalizá-lo.
*   O vídeo conclui que o desenvolvedor consegue terminar o jogo, mas não o faz por ser mais cômodo receber apoio financeiro contínuo, e sugere que o jogo só será finalizado quando o financiamento parar.
