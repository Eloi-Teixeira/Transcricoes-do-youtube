# Yandere Simulator: A Decadência de um Projeto

O vídeo apresenta uma análise informal e crítica sobre o desenvolvimento do jogo Yandere Simulator ao longo de 10 anos, utilizando uma linguagem direta e expressiva.

## Pontos-Chave

*   **Contexto Inicial:**
    *   Yandere Simulator foi originalmente um jogo com grande potencial, combinando elementos de Bully (Rockstar), estética anime, mecânicas de Hitman e uma trama de romance psicopata.
    *   O objetivo era eliminar 10 rivais em 10 semanas para a protagonista ficar com seu "Senpai".

*   **Problemas de Desenvolvimento:**
    *   Falta de foco e excesso de elementos adicionados ao jogo.
    *   Inúmeras tentativas de ajuda e ofertas de compra dos direitos do jogo foram rejeitadas pelo desenvolvedor.
    *   Apesar de atualizações constantes, o jogo não apresenta progresso significativo.

*   **Hype e Visibilidade:**
    *   O jogo ganhou destaque em 2016, impulsionado por youtubers.
    *   O criador do vídeo também se beneficiou do hype, atraindo muitos inscritos e visibilidade para seu canal.
    *   No entanto, a imagem do criador ficou muito atrelada a Yandere Simulator.

*   **Modo 1980 e a Decadência:**
    *   O lançamento do Modo 1980, um modo completo com 10 rivais jogando com a mãe da protagonista, escancarou a decadência do jogo original.
    *   A comunidade questiona por que um modo secundário está completo enquanto o principal não avança.
    *   O modo 1980 demonstra a capacidade do desenvolvedor de criar um jogo completo em menos de um ano.

*   **Teorias Sobre o Atraso:**
    *   O atraso é motivado por dinheiro, já que o desenvolvedor recebe financiamento mensal através do Patreon.
    *   A comunidade gringa continua a apoiar o projeto, mesmo com as polêmicas do desenvolvedor.
    *   O desenvolvedor é criticado por manter um ciclo vicioso de lentidão e polêmicas, oferecendo apenas "migalhas" aos fãs.

*   **Críticas ao Desenvolvedor:**
    *   O desenvolvedor é considerado burro por não lançar o jogo e aproveitar o potencial de vendas.
    *   O Modo 1980 revela que o desenvolvedor está enrolando propositalmente e não termina o jogo por ganância.

## Conclusão

*   O vídeo critica o desenvolvimento lento e problemático de Yandere Simulator ao longo de 10 anos.
*   A principal mensagem é que o desenvolvedor está propositalmente atrasando o lançamento do jogo para continuar recebendo financiamento.
*   A conclusão do vídeo é que o desenvolvedor é ganancioso e explora a comunidade, desperdiçando um projeto com potencial.
